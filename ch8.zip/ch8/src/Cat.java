
public class Cat extends Feline{
	public void eat(){
		System.out.println("I am eating as Cat!");
	}
	
	public void makeNoise(){
		System.out.println("My noise is as Cat");
	}
	public void setCatType(){
		System.out.println("I am Cat! A Feline");
	}	
}
