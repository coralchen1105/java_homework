
public class TestAnimal {
	
	Animal [] a = new Animal[6]; 
	
		
	public void animalAction(Animal a, String name, int size){
		
		a.eat();
		a.makeNoise();
		a.setName(name);
		a.setSize(size);
		
	}		
	
}
