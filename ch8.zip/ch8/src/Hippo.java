
public class Hippo extends Animal{
	
	public void eat(){
		System.out.println("I am eating as Hippo!");
	}
	
	public void makeNoise(){
		System.out.println("My noise is as Hippo");
	}
	public void setHippoType(){
		System.out.println("I am hippo! not Feline or Canine.");
	}	
}
