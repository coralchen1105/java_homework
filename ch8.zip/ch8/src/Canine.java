
public abstract class Canine extends Animal {
	
	public void setTypeCanine(){
		System.out.println("I am Canine");
	}
	
}
