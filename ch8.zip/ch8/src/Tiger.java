
public class Tiger extends Feline{
	public void eat(){
		System.out.println("I am eating as Tiger!");
	}
	
	public void makeNoise(){
		System.out.println("My noise is as Tiger");
	}
	public void setTigerType(){
		System.out.println("I am Tiger! A Feline");
	}	
}
