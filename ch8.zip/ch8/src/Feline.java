
public abstract class Feline extends Animal{
	
	public void setTypeFeline(){
		System.out.println("I am Feline");
	}
}
