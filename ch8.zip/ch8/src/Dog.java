
public class Dog extends Canine{
	public void eat(){
		System.out.println("I am eating as Dog!");
	}
	
	public void makeNoise(){
		System.out.println("My noise is as Dog");
	}
	public void setCatType(){
		System.out.println("I am Dog! A Canine");
	}	
}
