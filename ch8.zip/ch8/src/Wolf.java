
public class Wolf extends Canine{
	public void eat(){
		System.out.println("I am eating as Cat!");
	}
	
	public void makeNoise(){
		System.out.println("My noise is as Cat");
	}
	public void setWolfType(){
		System.out.println("I am cat! A Canine");
	}	
}
