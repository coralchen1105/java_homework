
public class Lion extends Feline{
	
	public void eat(){
		System.out.println("I am eating as Lion!");
	}
	
	public void makeNoise(){
		System.out.println("My noise is as Lion");
	}
	public void setLionType(){
		System.out.println("I am lion! A Feline");
	}	
}
