
public class eachAnimalTest {
	
	public static void main(String [] args){
		
		TestAnimal ta = new TestAnimal();
		Hippo h = new Hippo();
		Lion l = new Lion();
		ta.animalAction(h,"a",12);
		ta.animalAction(l,"b",14);
		
		
	}
}
